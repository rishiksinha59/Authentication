import Image from "next/image";
import SignUp from "./sign-up/page";

export default function Home() {
  return (
    <main className="">
      <SignUp/>
    </main>
  );
}
